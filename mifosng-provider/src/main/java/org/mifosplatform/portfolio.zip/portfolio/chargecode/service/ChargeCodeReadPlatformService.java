package org.mifosplatform.portfolio.chargecode.service;

public interface ChargeCodeReadPlatformService {

}
