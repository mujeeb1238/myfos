package org.mifosplatform.portfolio.billingcycle.service;

import org.mifosplatform.portfolio.billingcycle.data.BillingCycleData;

public interface BillingCycleReadPlatformService {

	BillingCycleData retrieveNewBillingCycleData();

}
