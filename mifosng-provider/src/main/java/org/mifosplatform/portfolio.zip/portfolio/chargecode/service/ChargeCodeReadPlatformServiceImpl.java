package org.mifosplatform.portfolio.chargecode.service;

public class ChargeCodeReadPlatformServiceImpl {

}
