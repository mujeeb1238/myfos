package org.mifosplatform.portfolio.savingsaccount.data;

public class SavingAccountForLookup {
	
	private final Long id;
	
	public SavingAccountForLookup(final Long id) {
		this.id = id;
	}

	public Long getId() {
		return this.id;
	}

}
